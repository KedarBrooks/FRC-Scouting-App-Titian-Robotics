//
//  PerformanceData_GameF+CoreDataProperties.m
//  5431 Scouting Application FRC
//
//  Created by learner on 2/11/16.
//  Copyright © 2016 Titian Robotics. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "PerformanceData_GameF+CoreDataProperties.h"

@implementation PerformanceData_GameF (CoreDataProperties)

@dynamic f_lowgoal_score;
@dynamic f_challenged_towers;
@dynamic f_boulder_pickup;
@dynamic f_highgoal_fails;
@dynamic f_highgoal_score;
@dynamic f_climbingtower;
@dynamic f_defensivepushing;
@dynamic f_lowgoal_fails;

@end
