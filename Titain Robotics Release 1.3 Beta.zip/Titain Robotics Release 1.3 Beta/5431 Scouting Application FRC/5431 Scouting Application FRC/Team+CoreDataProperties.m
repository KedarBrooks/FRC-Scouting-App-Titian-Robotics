//
//  Team+CoreDataProperties.m
//  5431 Scouting Application FRC
//
//  Created by learner on 2/11/16.
//  Copyright © 2016 Titian Robotics. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "Team+CoreDataProperties.h"

@implementation Team (CoreDataProperties)

@dynamic robot_type;
@dynamic team_bio;
@dynamic team_name;
@dynamic team_type;
@dynamic pData;
@dynamic fData;
@dynamic aData;

@end
