//
//  PerformanceData_GameF.m
//  5431 Scouting Application FRC
//
//  Created by learner on 2/11/16.
//  Copyright © 2016 Titian Robotics. All rights reserved.
//

#import "PerformanceData_GameF.h"

@implementation PerformanceData_GameF

// Insert code here to add functionality to your managed object subclass

@end
