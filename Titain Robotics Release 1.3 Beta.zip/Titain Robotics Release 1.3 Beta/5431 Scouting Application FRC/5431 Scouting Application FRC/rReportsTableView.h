//
//  rReportsTableView.h
//  5431 Scouting Application FRC
//
//  Created by Learenr on 2/18/16.
//  Copyright © 2016 Titian Robotics. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface rReportsTableView : UITableViewController

@end
