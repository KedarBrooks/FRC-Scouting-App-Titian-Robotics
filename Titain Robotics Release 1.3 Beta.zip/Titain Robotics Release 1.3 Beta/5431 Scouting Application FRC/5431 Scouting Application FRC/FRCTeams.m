//
//  FRCTeams.m
//  5431 Scouting Application FRC
//
//  Created by learner on 2/11/16.
//  Copyright © 2016 Titian Robotics. All rights reserved.
//

#import "FRCTeams.h"

@implementation FRCTeams

// Insert code here to add functionality to your managed object subclass

@end
