//
//  HomeViewViewController.h
//  5431 Scouting Application FRC
//
//  Created by learner on 4/1/16.
//  Copyright © 2016 Titian Robotics. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeViewViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>

@property (weak, nonatomic) IBOutlet UILabel *ReportTotal;


@end
