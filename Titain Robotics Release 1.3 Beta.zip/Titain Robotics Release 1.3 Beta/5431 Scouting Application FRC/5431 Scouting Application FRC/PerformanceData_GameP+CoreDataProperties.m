//
//  PerformanceData_GameP+CoreDataProperties.m
//  5431 Scouting Application FRC
//
//  Created by learner on 2/11/16.
//  Copyright © 2016 Titian Robotics. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "PerformanceData_GameP+CoreDataProperties.h"

@implementation PerformanceData_GameP (CoreDataProperties)

@dynamic cheval_de_frise_score;
@dynamic cheval_de_frise_speed;
@dynamic drawbridge_score;
@dynamic drawbridge_speed;
@dynamic lowbar_score;
@dynamic lowbar_speed;
@dynamic moat_score;
@dynamic moat_speed;
@dynamic portcullis_score;
@dynamic portcullis_speed;
@dynamic ramparts_score;
@dynamic ramparts_speed;
@dynamic rockwall_score;
@dynamic rockwall_speed;
@dynamic rough_terrain_score;
@dynamic rough_terrain_speed;
@dynamic sallyport_score;
@dynamic sallyport_speed;

@end
