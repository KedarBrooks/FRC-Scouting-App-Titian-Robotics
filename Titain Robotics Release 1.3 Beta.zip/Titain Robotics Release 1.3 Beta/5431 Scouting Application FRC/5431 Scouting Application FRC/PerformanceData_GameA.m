//
//  PerformanceData_GameA.m
//  5431 Scouting Application FRC
//
//  Created by learner on 2/11/16.
//  Copyright © 2016 Titian Robotics. All rights reserved.
//

#import "PerformanceData_GameA.h"

@implementation PerformanceData_GameA

// Insert code here to add functionality to your managed object subclass

@end
