//
//  Team.m
//  5431 Scouting Application FRC
//
//  Created by learner on 2/11/16.
//  Copyright © 2016 Titian Robotics. All rights reserved.
//

#import "Team.h"
#import "PerformanceData_GameA.h"
#import "PerformanceData_GameF.h"
#import "PerformanceData_GameP.h"

@implementation Team

// Insert code here to add functionality to your managed object subclass

@end
