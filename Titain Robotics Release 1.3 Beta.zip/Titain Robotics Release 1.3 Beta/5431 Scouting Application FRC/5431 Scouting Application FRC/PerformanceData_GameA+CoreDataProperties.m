//
//  PerformanceData_GameA+CoreDataProperties.m
//  5431 Scouting Application FRC
//
//  Created by learner on 2/11/16.
//  Copyright © 2016 Titian Robotics. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "PerformanceData_GameA+CoreDataProperties.h"

@implementation PerformanceData_GameA (CoreDataProperties)

@dynamic a_boulder_start;
@dynamic a_defense_reached;
@dynamic a_crossed_defenses;
@dynamic a_lowgoal_score;
@dynamic a_highgoal_score;

@end
