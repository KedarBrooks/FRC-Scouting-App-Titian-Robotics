//
//  TeamTableView.h
//  5431 Scouting Application FRC
//
//  Created by Kedar Brooks on 4/1/16.
//  Copyright © 2016 Titian Robotics. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TeamTableView : UIViewController <UITableViewDelegate, UITableViewDataSource>

@end
