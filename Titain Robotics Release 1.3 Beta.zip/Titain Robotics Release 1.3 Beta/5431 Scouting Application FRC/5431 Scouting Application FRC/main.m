//
//  main.m
//  5431 Scouting Application FRC
//
//  Created by Titian Robotics on 1/27/16.
//  Copyright © 2016 Titian Robotics. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
    
    
}
