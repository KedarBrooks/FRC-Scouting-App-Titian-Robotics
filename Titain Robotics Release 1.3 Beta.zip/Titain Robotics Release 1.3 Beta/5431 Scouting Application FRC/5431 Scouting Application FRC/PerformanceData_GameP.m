//
//  PerformanceData_GameP.m
//  5431 Scouting Application FRC
//
//  Created by learner on 2/11/16.
//  Copyright © 2016 Titian Robotics. All rights reserved.
//

#import "PerformanceData_GameP.h"

@implementation PerformanceData_GameP

// Insert code here to add functionality to your managed object subclass

@end
