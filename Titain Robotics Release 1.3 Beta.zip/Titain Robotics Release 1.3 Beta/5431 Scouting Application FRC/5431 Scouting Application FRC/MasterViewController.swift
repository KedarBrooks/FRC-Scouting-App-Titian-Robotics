//
//  MasterViewController.swift
//  5431 Scouting Application FRC
//
//  Created by learner on 2/5/16.
//  Copyright © 2016 Titian Robotics. All rights reserved.
//

import Cocoa

class MasterViewController: UITableViewController {
    
    

}
