//
//  ScoutDataTableTableViewController.h
//  5431 Scouting Application FRC
//
//  Created by learner on 4/1/16.
//  Copyright © 2016 Titian Robotics. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ScoutDataTableTableViewController : UITableViewController

@end
